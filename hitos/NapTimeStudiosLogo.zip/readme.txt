Logo de juego + equipo
Proyecto 3
Juego: Holy Spoons
Equipo: Nap Time Studios
