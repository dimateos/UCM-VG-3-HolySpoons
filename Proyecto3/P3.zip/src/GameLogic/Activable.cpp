#include "Activable.h"

std::list<Activable*> Activable::changedActive_ = {};
